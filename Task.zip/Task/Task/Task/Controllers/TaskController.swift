//
//  TaskController.swift
//  Task
//
//  Created by Brayden Harris on 1/30/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import Foundation
import CoreData

class TaskController {
    
    let fetchedResultsController: NSFetchedResultsController<Task>  = {
        let fetchRequest: NSFetchRequest<Task> = Task.fetchRequest()
        let isCompleteSort = NSSortDescriptor(key: "isComplete", ascending: true)
        let dueSort = NSSortDescriptor(key: "due", ascending: true)
        fetchRequest.sortDescriptors = [isCompleteSort, dueSort]
        
        return NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: CoreDataStack.context, sectionNameKeyPath: "isComplete", cacheName: nil)
    }()
    
    init() {
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("Error loading fetchedResultsController: \(error): \(error.localizedDescription)")
        }
    }
    
    static let shared = TaskController()
    
    
    func add(taskWithName name: String, note: String?, due: Date?) {
        Task(name: name, notes: note, due: due)
        saveToPersistentStore()
    }
    
    func update(task: Task, name: String, notes: String?, due: Date?) {
        task.name = name
        task.notes = notes
        task.due = due
        
        saveToPersistentStore()
    }
    
    func remove(task: Task) {
        task.managedObjectContext?.delete(task)
        saveToPersistentStore()
    }
    
    func toggleIsCompleteFor(task: Task) {
        task.isComplete = !task.isComplete
        saveToPersistentStore()
    }
    
//MARK: - Persistence

    func saveToPersistentStore() {
        do {
            try CoreDataStack.context.save()
        } catch {
            print("Error saving Managed Object Context. \(error): \(error.localizedDescription)")
        }
        
    }
    
//    func fetchTasks() -> [Task] {
//        let request: NSFetchRequest<Task> = Task.fetchRequest()
//        do {
//            return try CoreDataStack.context.fetch(request)
//        } catch {
//            print("There was a problem loading Tasks from the persistent Store \(error): \(error.localizedDescription)")
//            return []
//        }
//    }
}
