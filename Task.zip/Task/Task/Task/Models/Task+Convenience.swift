//
//  Task+Convenience.swift
//  Task
//
//  Created by Brayden Harris on 1/30/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import Foundation
import CoreData

extension Task {
    
    @discardableResult
    convenience init(name: String, notes: String? = nil, due: Date? = nil, isComplete: Bool = false, context: NSManagedObjectContext = CoreDataStack.context) {
        self.init(context: context)
        
        self.name = name
        self.notes = notes
        self.due = due
        self.isComplete = isComplete
    }
}
