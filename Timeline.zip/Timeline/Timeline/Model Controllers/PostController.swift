//
//  PostController.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit
import CloudKit

class PostController {
    
    init() {
        subscribeToNewPosts { (success, error) in
            if let error = error {
                print("Error subscribing to new posts: \(error), \(error.localizedDescription)")
                return
            }
            if success {
                print("Subscribed to all new posts!")
            }
        }
    }
    
    // MARK: - Singleton/Shared Instance
    static let sharedController = PostController()
    
    // MARK: - Source of Truth
    var posts: [Post] = [] {
        didSet {
            DispatchQueue.main.async {
                let nc = NotificationCenter.default
                nc.post(name: PostController.PostsChangedNotification, object: self)
            }
        }
    }
    
    let publicDB = CKContainer.default().publicCloudDatabase
    
    func addComment(toPost post: Post, text: String, completion: @escaping (Comment?) -> Void) {
        let comment = Comment(text: text, post: post)
        post.comments.append(comment)
        post.commentCount += 1
        let commentRecord = CKRecord(comment: comment)
        let postRecord = CKRecord(post: post)
        
        publicDB.save(commentRecord) { (record, error) in
            if let error = error {
                print("Error saving comment record to CloudKit: \(error), \(error.localizedDescription)")
                completion(nil)
                return
            }
            guard let record = record else { completion(nil); return }
            
            let modifyRecordsOp = CKModifyRecordsOperation(recordsToSave: [postRecord], recordIDsToDelete: nil)
            self.publicDB.add(modifyRecordsOp)
            completion(Comment(record: record, post: post))
        }
    }
    
    func createPostWith(image: UIImage, caption: String, completion: @escaping (Post?) -> Void) {
        let post = Post(photo: image, caption: caption)
        self.posts.append(post)
        let postRecord = CKRecord(post: post)
        publicDB.save(postRecord) { (record, error) in
            if let error = error {
                print("Error saving post record to CloudKit: \(error), \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let record = record else { completion(nil); return }
            completion(Post(record: record))
        }
    }
    
    func fetchPosts(completion: @escaping ([Post]?) -> Void) {
        
        let predicate = NSPredicate(value: true)
        
        let query = CKQuery(recordType: Post.typeKey, predicate: predicate)
        
        publicDB.perform(query, inZoneWith: nil) { (records, error) in
            if let error = error {
                print("Error fetching posts from CloudKit: \(error), \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let records = records else { completion(nil); return }
            
            let posts = records.compactMap { Post(record: $0) }
            
            self.posts = posts
            
            completion(posts)
        }
    }
    
    func fetchComments(for post: Post, completion: @escaping (Bool) -> Void) {
        
        let postReference = CKRecord.Reference(recordID: post.recordID, action: .deleteSelf)
        let predicate = NSPredicate(format: "postReference == %@", postReference)
        
        let commentIDs = post.comments.compactMap { $0.recordID }
        let predicate2 = NSPredicate(format: "NOT(recordID IN %@)", commentIDs)
        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [predicate, predicate2])
        
        let query = CKQuery(recordType: Comment.typeKey, predicate: compoundPredicate)
        
        publicDB.perform(query, inZoneWith: nil) { (records, error) in
            if let error = error {
                print("Error fetching comments from CloudKit: \(error), \(error.localizedDescription)")
                completion(false)
                return
            }
            
            guard let records = records else { completion(false); return }
            
            let comments = records.compactMap{ Comment(record: $0, post: post) }
            
            post.comments.append(contentsOf: comments)
            post.commentCount += comments.count
            
            completion(true)
        }
    }
    
    func checkAccountStatus(completion: @escaping (Bool) -> Void) {
        
        CKContainer.default().accountStatus { (status, error) in
            if let error = error {
                print("Unable to retrieve account status: \(error), \(error.localizedDescription)")
                completion(false)
                return
            }
            
            DispatchQueue.main.async {
                switch status {
                    
                case .available:
                    completion(true)
                case .couldNotDetermine:
                    self.presentSimpleAlertWith(title: "Can't Determine Account Status", message: "An error occurred during an attempt to retrieve the account status")
                    completion(false)
                case .noAccount:
                    self.presentSimpleAlertWith(title: "No Account", message: "No iCloud account information has been provided for this device")
                    completion(false)
                case.restricted:
                    self.presentSimpleAlertWith(title: "Account Restricted", message: "Access was denied due to Parental Controls or Mobile Device Management restrictions")
                    completion(false)
                }
            }
        }
    }
    
    func presentSimpleAlertWith(title: String, message: String) {
        DispatchQueue.main.async {
            if let appDelegate = UIApplication.shared.delegate,
                let appWindow = appDelegate.window,
                let rootViewController = appWindow?.rootViewController {
                rootViewController.showAlertMessage(title: title, message: message)
            }
        }
    }
    
    func subscribeToNewPosts(completion: ((Bool, Error?) -> Void)?) {
        
        let predicate = NSPredicate(value: true)
        let subscription = CKQuerySubscription(recordType: Post.typeKey, predicate: predicate, subscriptionID: "subscribe", options: .firesOnRecordCreation)
        
        let notificationInfo = CKQuerySubscription.NotificationInfo()
        notificationInfo.alertBody = "New post on timeline"
        notificationInfo.shouldBadge = true
        notificationInfo.shouldSendContentAvailable = true
        subscription.notificationInfo = notificationInfo
        
        publicDB.save(subscription) { (_, error) in
            if let error = error {
                print("Error saving subscription to publicDB: \(error), \(error.localizedDescription)")
                if let completion = completion {
                    completion(false, error)
                }
                return
            }
            if let completion = completion {
                completion(true, nil)
            }
        }
    }
    
    func addSubscriptionTo(commentsForPost post: Post, completion: ((Bool, Error?) -> Void)?) {
        let predicate = NSPredicate(format: "postReference == %@", post.recordID)
        
        let subscription = CKQuerySubscription(recordType: Comment.typeKey, predicate: predicate, subscriptionID: post.recordID.recordName, options: .firesOnRecordCreation)
        
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.alertBody = "New comment for post!"
        notificationInfo.shouldSendContentAvailable = true
        notificationInfo.desiredKeys = nil
        
        subscription.notificationInfo = notificationInfo
        
        publicDB.save(subscription) { (_, error) in
            if let error = error {
                print("Error saving comments subscription to publicDB: \(error), \(error.localizedDescription)")
                if let completion = completion {
                    completion(false, error)
                }
                return
            }
            if let completion = completion {
                completion(true, nil)
            }
        }
    }
    
    func removeSubscriptionTo(commentsForPost post: Post, completion: ((Bool, Error?) -> Void)?) {
        publicDB.delete(withSubscriptionID: post.recordID.recordName) { (_, error) in
            if let error = error {
                print("Error deleting subscription: \(error), \(error.localizedDescription)")
                if let completion = completion {
                    completion(false, error)
                }
                return
            }
            if let completion = completion {
                completion(true, nil)
            }
        }
    }
    
    func checkForSubscription(to post: Post, completion: ((Bool) -> Void)?) {
        publicDB.fetch(withSubscriptionID: post.recordID.recordName) { (subscription, error) in
            if let error = error {
                print("Error fetching subscription from post: \(error), \(error.localizedDescription)")
                    completion?(false)
                return
            }
            if subscription != nil {
                completion?(true)
            } else {
                completion?(false)
            }
        }
    }
    
    func toggleSubscription(to post: Post, completion: ((Bool, Error?) -> Void)?) {
        checkForSubscription(to: post) { (success) in
            if success == false {
                self.addSubscriptionTo(commentsForPost: post, completion: nil)
            } else {
                self.removeSubscriptionTo(commentsForPost: post, completion: nil)
            }
            
        }
    }
}
extension PostController {
    static let PostsChangedNotification = Notification.Name("PostsChangedNotification")
    static let PostCommentsChangedNotification = Notification.Name("PostCommentsChangedNotification")
}
