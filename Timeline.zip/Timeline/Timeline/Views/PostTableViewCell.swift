//
//  PostTableViewCell.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    var post: Post? {
        didSet {
            self.updateViews()
        }
    }
    
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var captionLabel: UILabel!
    @IBOutlet weak var commentsLabel: UILabel!
    
    func updateViews() {
        if let post = post {
            
            PostController.sharedController.fetchComments(for: post) { (success) in
                if success {
                    DispatchQueue.main.async {
                        self.commentsLabel.text = "Comments: \(post.commentCount)"
                    }
                }
            }
            postImageView.image = post.photo
            captionLabel.text = post.caption
            
        }
    }

}
