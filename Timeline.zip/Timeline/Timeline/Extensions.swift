//
//  Extensions.swift
//  Timeline
//
//  Created by Brayden Harris on 2/28/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

extension UIViewController {
    func showAlertMessage(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
