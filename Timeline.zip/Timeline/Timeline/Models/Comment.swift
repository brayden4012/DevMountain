//
//  Comment.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import Foundation
import CloudKit

class Comment: SearchableRecord {
    
    static let typeKey = "Comment"
    fileprivate static let textKey = "text"
    fileprivate static let timestampKey = "timestamp"
    fileprivate static let postReferenceKey = "postReference"
    
    var text: String
    var timestamp: Date
    var post: Post?
    var recordID: CKRecord.ID
    
    init(text: String, post: Post, timestamp: Date = Date(), recordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString)) {
        self.text = text
        self.timestamp = timestamp
        self.post = post
        self.recordID = recordID
    }
    
    convenience init?(record: CKRecord, post: Post) {
        
        guard let text = record[Comment.textKey] as? String,
            let timestamp = record[Comment.timestampKey] as? Date else { return nil }
        
        self.init(text: text, post: post, timestamp: timestamp, recordID: record.recordID)
    }
    
    func matches(searchTerm: String) -> Bool {
        return self.text.lowercased().contains(searchTerm.lowercased()) 
    }
    
}

extension CKRecord {
    
    convenience init(comment: Comment) {
        guard let post = comment.post else {
            fatalError("Comment does not have a Post relationship")
        }
        
        self.init(recordType: Comment.typeKey, recordID: comment.recordID)
        
        self.setValue(comment.text, forKey: Comment.textKey)
        self.setValue(comment.timestamp, forKey: Comment.timestampKey)
        self.setValue(CKRecord.Reference(recordID: post.recordID, action: .deleteSelf), forKey: Comment.postReferenceKey)

    }
}
