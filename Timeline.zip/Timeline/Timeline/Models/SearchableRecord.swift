//
//  SearchableRecord.swift
//  Timeline
//
//  Created by Brayden Harris on 2/27/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import Foundation

protocol SearchableRecord {
    func matches(searchTerm: String) -> Bool
}
