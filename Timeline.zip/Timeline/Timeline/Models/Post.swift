//
//  Post.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit
import CloudKit

class Post: SearchableRecord  {

    static let typeKey = "Post"
    fileprivate static let photoDataKey = "photoData"
    fileprivate static let captionKey = "caption"
    fileprivate static let timestampKey = "timestamp"
    fileprivate static let commentCountKey = "commentCount"
    
    var photoData: Data?
    var caption: String
    var timestamp: Date
    var comments: [Comment] {
        didSet {
            DispatchQueue.main.async {
                let nc = NotificationCenter.default
                nc.post(name: PostController.PostCommentsChangedNotification, object: self)
            }
        }
    }
    var photo: UIImage? {
        get {
            guard let photoData = photoData else { return nil }
            return UIImage(data: photoData)
        }
        set {
            photoData = newValue?.jpegData(compressionQuality: 0.6)
        }
        
    }
    let recordID: CKRecord.ID
    var commentCount: Int
    var tempURL: URL?
    
    var imageAsset: CKAsset? {
        get {
            let tempDirectory = NSTemporaryDirectory()
            let tempDirectoryURL = URL(fileURLWithPath: tempDirectory)
            let fileURL = tempDirectoryURL.appendingPathComponent(UUID().uuidString).appendingPathExtension("jpg")
//            self.tempURL = fileURL
            do {
                try photoData?.write(to: fileURL)
            } catch let error {
                print("Error writing to temp URL: \(error), \(error.localizedDescription)")
            }
            return CKAsset(fileURL: fileURL)
        }
    }
    
//    deinit {
//        if let url = tempURL {
//            do {
//                try FileManager.default.removeItem(at: url)
//            } catch let error {
//                print("Error deleting temp file, or may cause memory leak: \(error)")
//            }
//        }
//    }
    
    init(photo: UIImage?, caption: String, timestamp: Date = Date(), comments: [Comment] = [], recordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString), commentCount: Int = 0) {
        self.caption = caption
        self.timestamp = timestamp
        self.comments = comments
        self.recordID = recordID
        self.commentCount = commentCount
        self.photo = photo
    }
    
    func matches(searchTerm: String) -> Bool {
        if caption.contains(searchTerm) {
            return true
        }
        
        for comment in comments {
            if comment.text.contains(searchTerm) {
                return true
            }
        }
        
        return false
    }
    
    init?(record: CKRecord) {
        guard let caption = record[Post.captionKey] as? String,
            let timestamp = record[Post.timestampKey],
            let commentCount = record[Post.commentCountKey] as? Int,
            let imageAsset = record[Post.photoDataKey] as? CKAsset else { return nil }
        
        guard let photoData = try? Data(contentsOf: imageAsset.fileURL) else { return nil }
        
        self.photoData = photoData
        self.caption = caption
        self.timestamp = timestamp as? Date ?? Date()
        self.comments = []
        self.recordID = record.recordID
        self.commentCount = commentCount
        
    }
}
extension Post: Equatable {
    static func == (lhs: Post, rhs: Post) -> Bool {
        return lhs.recordID == rhs.recordID
    }
    
    
}
extension CKRecord {
    
    convenience init(post: Post) {
        self.init(recordType: Post.typeKey, recordID: post.recordID)
        
        self.setValue(post.caption, forKey: Post.captionKey)
        self.setValue(post.timestamp, forKey: Post.timestampKey)
        self.setValue(post.imageAsset, forKey: Post.photoDataKey)
        self.setValue(post.commentCount, forKey: Post.commentCountKey)
    }
}
