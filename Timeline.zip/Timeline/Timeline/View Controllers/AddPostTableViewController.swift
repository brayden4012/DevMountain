//
//  AddPostTableViewController.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class AddPostTableViewController: UITableViewController, UIImagePickerControllerDelegate {

    @IBOutlet weak var captionTextField: UITextField!
    
    var photo: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        captionTextField.text = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toPhotoSelectVC"{
            guard let destinationVC = segue.destination as? PhotoSelectorViewController else {return}
            destinationVC.delegate = self
        }
    }
    
    @IBAction func addPostButtonTapped(_ sender: Any) {
        guard let image = photo,
            let caption = captionTextField.text,
            !caption.isEmpty else { return }
        
        PostController.sharedController.createPostWith(image: image, caption: caption) { (post) in
            DispatchQueue.main.async {
                self.tabBarController?.selectedIndex = 0
            }
        }
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        DispatchQueue.main.async {
            self.tabBarController?.selectedIndex = 0
        }
    }
}
extension AddPostTableViewController: PhotoSelectorViewControllerDelegate {
    func photoSelectorViewControllerSelected(image: UIImage) {
        self.photo = image
    }
}
