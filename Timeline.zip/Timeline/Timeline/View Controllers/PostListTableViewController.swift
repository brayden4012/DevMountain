//
//  PostListTableViewController.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class PostListTableViewController: UITableViewController {

    var isSearching = false
    
    var dataSource: [Post] {
        if isSearching {
            guard let results = searchResults else { return [] }
            return results
        } else {
            print("\(PostController.sharedController.posts.count)")
            return PostController.sharedController.posts
        }
    }
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    var searchResults: [Post]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        
        requestFullSyncOp { (success) in
            if success {
                self.reloadTableView()
            }
        }
        
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(postsChanged(_:)), name: PostController.PostsChangedNotification, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reloadTableView()
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func requestFullSyncOp(completion: @ escaping (Bool) -> Void) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        PostController.sharedController.fetchPosts { (posts) in
            guard let posts = posts else { completion(false); return }
            DispatchQueue.main.async {
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
            print("All user posts fetched: \(posts.count)")
            completion(true)
        }
        
    }

    @objc func postsChanged(_ notification: Notification) {
        reloadTableView()
    }
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return dataSource.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "postCell", for: indexPath) as? PostTableViewCell
        
        cell?.post = dataSource[indexPath.row]

        return cell ?? UITableViewCell()
    }

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetailSegue" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let destinationVC = segue.destination as? PostDetailTableViewController
                destinationVC?.post = dataSource[indexPath.row]
            }
        }
    }

}

extension PostListTableViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchResults = PostController.sharedController.posts.filter { (post) -> Bool in
            return post.matches(searchTerm: searchText)
        }
        reloadTableView()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchResults = PostController.sharedController.posts
        searchBar.text = ""
        searchBar.resignFirstResponder()
        reloadTableView()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSearching = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSearching = false
    }
}
