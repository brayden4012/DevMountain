//
//  PostDetailTableViewController.swift
//  Timeline
//
//  Created by Brayden Harris on 2/26/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class PostDetailTableViewController: UITableViewController {

    // Landing Pad
    var post: Post? {
        didSet {
            self.loadViewIfNeeded()
            self.updateViews()
        }
    }
    
    // MARK: - Date Formatter
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }()
    
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var followButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(commentsChanged(_:)), name: PostController.PostCommentsChangedNotification, object: nil)
    }
    
    @objc func commentsChanged(_ notification: Notification) {
        if notification.object as? Post == self.post {
            updateViews()
        }
    }
    
    func updateViews() {
        if let post = post {
            PostController.sharedController.checkForSubscription(to: post) { (success) in
                if success {
                    DispatchQueue.main.async {
                        self.followButton.setTitle("Unfollow", for: .normal)
                    }
                } else {
                    DispatchQueue.main.async {
                        self.followButton.setTitle("Follow", for: .normal)
                    }
                }
            }
            DispatchQueue.main.async {
                self.postImageView.image = post.photo
                self.tableView.reloadData()
            }
        }
    }

    @IBAction func commentButtonTapped(_ sender: Any) {
        guard let post = post else { return }
        
        let alertController = UIAlertController(title: "Add Comment", message: nil, preferredStyle: .alert)
        
        alertController.addTextField { (textField) in
            textField.placeholder = "Enter a comment..."
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (cancelAction) in
            print("Cancel add comment")
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (okAction) in
            guard let text = alertController.textFields?[0].text,
                !text.isEmpty else { return }
            
            PostController.sharedController.addComment(toPost: post, text: text, completion: { (comment) in
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            })
        }
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        
        present(alertController, animated: true)
        
    }
    
    @IBAction func shareButtonTapped(_ sender: Any) {
        guard let post = post, let photo = post.photo else { return }
        let activityVC = UIActivityViewController(activityItems: [photo, post.caption], applicationActivities: nil)
        DispatchQueue.main.async {
            self.present(activityVC, animated: true)
        }
    }
    
    @IBAction func followButtonTapped(_ sender: Any) {
        guard let post = post else { return }
        PostController.sharedController.toggleSubscription(to: post, completion: nil)
        updateViews()
    }
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        guard let post = post else { return 0 }
        return post.commentCount
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath)

        guard let post = post else { return UITableViewCell() }
        cell.textLabel?.text = post.comments[indexPath.row].text
        cell.detailTextLabel?.text = dateFormatter.string(from: post.comments[indexPath.row].timestamp)

        return cell
    }
}
