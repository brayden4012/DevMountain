//
//  PhotoSelectorViewController.swift
//  Timeline
//
//  Created by Brayden Harris on 2/27/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

protocol PhotoSelectorViewControllerDelegate: class{
    func photoSelectorViewControllerSelected(image: UIImage)
}

class PhotoSelectorViewController: UIViewController {

    weak var delegate: PhotoSelectorViewControllerDelegate?
    
    @IBOutlet weak var selectImageButton: UIButton!
    @IBOutlet weak var photoImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        selectImageButton.setTitle("Select Image", for: .normal)
        photoImageView.image = nil
    }
    
    @IBAction func selectImageButtonTapped(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let alertController = UIAlertController(title: "Select an Image", message: nil, preferredStyle: .actionSheet)
        
        let libraryAction: UIAlertAction
        let cameraAction: UIAlertAction
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            libraryAction = UIAlertAction(title: "Add from library", style: .default) { (_) in
                imagePickerController.sourceType = .photoLibrary
                self.present(imagePickerController, animated: true)
            }
            alertController.addAction(libraryAction)
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            cameraAction = UIAlertAction(title: "Take a photo", style: .default) { (cameraAction) in
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true)
            }
            alertController.addAction(cameraAction)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true)
        
        selectImageButton.titleLabel?.text = ""
    }

}

extension PhotoSelectorViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        if let photo = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            selectImageButton.setTitle("", for: .normal)
            photoImageView.image = photo
            delegate?.photoSelectorViewControllerSelected(image: photo)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
