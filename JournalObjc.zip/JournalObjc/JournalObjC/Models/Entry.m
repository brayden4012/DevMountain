//
//  Entry.m
//  JournalObjC
//
//  Created by Brayden Harris on 2/11/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "Entry.h"

@implementation Entry

- (instancetype)initWithTitle:(NSString *)title bodyText:(NSString *)bodyText timestamp:(NSDate *)timestamp
{
    self = [super init];
    if (self) {
        _title = title;
        _bodyText = bodyText;
        _timestamp = timestamp;
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSString *title = dictionary[@"title"];
    NSString *bodyText = dictionary[@"text"];
    NSDate *timestamp = dictionary[@"timestamp"];
    return [self initWithTitle:title bodyText:bodyText timestamp:timestamp];
}

- (NSDictionary *)dictionaryCopy
{
    return @{
             @"title": self.title,
             @"text": self.bodyText,
             @"timestamp": self.timestamp
             };
}

@end
