//
//  EntryController.m
//  JournalObjC
//
//  Created by Brayden Harris on 2/11/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "EntryController.h"

@implementation EntryController

+ (EntryController *)sharedInstance
{
    static EntryController *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[EntryController alloc] init];
        sharedInstance.entries = [NSMutableArray new];
    });
    return sharedInstance;
}

- (void)addEntry:(Entry *)entry
{
    [_entries addObject:entry];
    [self saveToPersistentStorage];
}

- (void)removeEntry:(Entry *)entry
{
    [_entries removeObject:entry];
    [self saveToPersistentStorage];
}

- (void)modifyEntry:(Entry *)entry withTitle:(NSString *)title body:(NSString *)body
{
    entry.title = title;
    entry.bodyText = body;
    [self saveToPersistentStorage];
}

- (void)saveToPersistentStorage
{
    NSMutableArray *entryDictionaries = [NSMutableArray new];
    
    for (Entry *entry in self.entries) {
        [entryDictionaries addObject:entry.dictionaryCopy];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:entryDictionaries forKey:@"Entries"];
}

- (void)loadFromPersistentStorage
{
    NSArray *entryDictionaries = [[NSUserDefaults standardUserDefaults] objectForKey:@"Entries"];
    
    for (NSDictionary *dictionary in entryDictionaries) {
        Entry *entry = [[Entry new] initWithDictionary:dictionary];
        [self addEntry:entry];
    }
}

@end
