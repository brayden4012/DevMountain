//
//  EntryController.h
//  JournalObjC
//
//  Created by Brayden Harris on 2/11/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Entry.h"

NS_ASSUME_NONNULL_BEGIN

@interface EntryController : NSObject

@property (nonatomic, strong) NSMutableArray *entries;

+ (EntryController *)sharedInstance;

- (void)addEntry:(Entry *)entry;

- (void)removeEntry:(Entry *)entry;

- (void)modifyEntry:(Entry *)entry withTitle:(NSString *)title body: (NSString *)body;

- (void)saveToPersistentStorage;

- (void)loadFromPersistentStorage;

@end

NS_ASSUME_NONNULL_END
