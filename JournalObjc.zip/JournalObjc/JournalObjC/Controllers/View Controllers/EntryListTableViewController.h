//
//  EntryListTableViewController.h
//  JournalObjC
//
//  Created by Brayden Harris on 2/11/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EntryController.h"
#import "EntryDetailViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface EntryListTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
