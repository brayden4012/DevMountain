//
//  EntryDetailViewController.m
//  JournalObjC
//
//  Created by Brayden Harris on 2/11/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "EntryDetailViewController.h"

@interface EntryDetailViewController ()

@property (weak, nonatomic) IBOutlet UITextField *titleTextField;
@property (weak, nonatomic) IBOutlet UITextView *textBodyTextView;

@end

@implementation EntryDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (_entry) {
        self.title = @"";
    }
    [self updateViews];
}

- (void)updateViews {
    if (_entry) {
        _titleTextField.text = _entry.title;
        _textBodyTextView.text = _entry.bodyText;
    }
}

- (IBAction)clearButtonTapped:(id)sender {
    _titleTextField.text = @"";
    _textBodyTextView.text = @"";
}

- (IBAction)saveButtonTapped:(id)sender {
    if (_entry) {
        [[EntryController sharedInstance] modifyEntry:_entry withTitle:_titleTextField.text body:_textBodyTextView.text];
    } else {
        Entry *newEntry = [[Entry alloc] initWithTitle:_titleTextField.text bodyText:_textBodyTextView.text timestamp:[NSDate date]];
        [[EntryController sharedInstance] addEntry:newEntry];
    }
    [self.navigationController popViewControllerAnimated:true];
}


@end
