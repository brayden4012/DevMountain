//
//  EntryListTableViewController.m
//  JournalObjC
//
//  Created by Brayden Harris on 2/11/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "EntryListTableViewController.h"

@interface EntryListTableViewController ()

@end

@implementation EntryListTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[EntryController sharedInstance] loadFromPersistentStorage];
}
    
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [[[EntryController sharedInstance] entries] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"entryCell" forIndexPath:indexPath];
    
    cell.textLabel.text = [[[EntryController sharedInstance] entries][indexPath.row] title];
    
    return cell;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        Entry *entryToRemove = [[EntryController sharedInstance]entries][indexPath.row];
        [[[EntryController sharedInstance] entries] removeObject:entryToRemove];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }  
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"toDetailSegue"]) {
        NSIndexPath *index = [self.tableView indexPathForSelectedRow];
        EntryDetailViewController *detailVC = [segue destinationViewController];
        Entry *entryToSend = [[EntryController sharedInstance]entries][index.row];
        detailVC.entry = entryToSend;
    }
}
@end
