//
//  AlarmController.swift
//  Alarm
//
//  Created by Brayden Harris on 1/28/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import Foundation
import UserNotifications

class AlarmController: AlarmScheduler {
    
    //MARK: - Shared instance/Singleton
    static let shared = AlarmController()
    
    //MARK: - Source of Truth
    var alarms: [Alarm] = []
    
    //MARK: - CRUD Functions
    func addAlarm(fireDate: Date, name: String, enabled: Bool) {
        let alarm = Alarm(fireDate: fireDate, name: name)
        alarm.enabled = enabled
        AlarmController.shared.alarms.append(alarm)
        scheduleUserNotification(for: alarm)
        
        saveToPersistentStorage()
    }
    
    func update(alarm: Alarm, fireDate: Date, name: String, enabled: Bool) {
        
        cancelUserNotification(for: alarm)
        
        alarm.name = name
        alarm.fireDate = fireDate
        alarm.enabled = enabled
        
        scheduleUserNotification(for: alarm)
        
        saveToPersistentStorage()
    }
    
    func delete(alarm: Alarm) {
        guard let alarmIndex = AlarmController.shared.alarms.index(of: alarm) else { return }
        self.cancelUserNotification(for: alarm)
        alarms.remove(at: alarmIndex)
        
        saveToPersistentStorage()
    }
    
    func toggleEnabled(for alarm: Alarm) {
        alarm.enabled = !alarm.enabled
        
        if alarm.enabled {
            scheduleUserNotification(for: alarm)
        } else {
            cancelUserNotification(for: alarm)
        }
    }
    
    //MARK: - Persistence
    func fileURL() -> URL {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = path[0]
        let fileName = "alarm.json"
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        
        return fileURL
    }
    
    func saveToPersistentStorage() {
        let je = JSONEncoder()
        
        do{
            let data = try je.encode(alarms)
            try data.write(to: fileURL())
        } catch{
            print("Failed to Save to Persistent Store \(error) \(error.localizedDescription)")
        }
    }
    
    func loadFromPersistentStorage() {
        let jd = JSONDecoder()
        
        do {
            let data = try Data(contentsOf: fileURL())
            let alarms = try jd.decode([Alarm].self, from: data)
            self.alarms = alarms
        } catch {
            print("Failed to Load from Persistent Store \(error) \(error.localizedDescription)")
        }
    }
}

protocol AlarmScheduler: class{
    func scheduleUserNotification(for alarm: Alarm)
    func cancelUserNotification(for alarm: Alarm)
}

extension AlarmScheduler {
    
    func scheduleUserNotification(for alarm: Alarm){
        
        let content = UNMutableNotificationContent()
        content.title = "Time to get up"
        content.body = "Your alarm named \(alarm.name) is going off!"
        content.sound = UNNotificationSound.default
        
        let components = Calendar.current.dateComponents([.hour, .minute, .second], from: alarm.fireDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        let request = UNNotificationRequest(identifier: alarm.uuid, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request) { (error) in
            if let error = error{
                print("Error scheduling local user notifications \(error.localizedDescription)  :  \(error)")
            }
        }
    }
    
    func cancelUserNotification(for alarm: Alarm){
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [alarm.uuid])
    }
}
