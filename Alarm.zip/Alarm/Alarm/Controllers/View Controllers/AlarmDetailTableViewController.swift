//
//  AlarmDetailTableViewController.swift
//  Alarm
//
//  Created by Brayden Harris on 1/28/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class AlarmDetailTableViewController: UITableViewController, AlarmScheduler {

    // MARK: - IBOutlets
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var enableButton: UIButton!
    
    var alarm: Alarm? {
        didSet {
            loadViewIfNeeded()
            self.updateViews()
        }
    }
    
    var alarmIsOn: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
    func updateViews() {
        guard let alarm = alarm else { return }
        datePicker.date = alarm.fireDate
        nameTextField.text = alarm.name
        alarmIsOn = alarm.enabled
        
        if alarmIsOn == true {
            enableButton.backgroundColor = .green
            enableButton.setTitle("ON", for: .normal)
        } else {
            enableButton.backgroundColor = .gray
            enableButton.setTitle("OFF", for: .normal)
        }
    }

    //MARK: - IBActions
    @IBAction func enableButtonTapped(_ sender: Any) {
        if let alarm = alarm {
            AlarmController.shared.toggleEnabled(for: alarm)
            alarmIsOn = alarm.enabled
        } else {
            alarmIsOn = !alarmIsOn
        }
        if alarmIsOn == true {
            enableButton.backgroundColor = .green
            enableButton.setTitle("ON", for: .normal)
        } else {
            enableButton.backgroundColor = .gray
            enableButton.setTitle("OFF", for: .normal)
        }
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        guard let title = nameTextField.text, title != "" else { return }
        if let alarm = alarm {
            AlarmController.shared.update(alarm: alarm, fireDate: datePicker.date, name: title, enabled: alarmIsOn)
        } else {
            AlarmController.shared.addAlarm(fireDate: datePicker.date, name: title, enabled: alarmIsOn)
        }
        self.navigationController?.popViewController(animated: true)
    }
}
