//
//  BMHPhotoCollectionViewCell.h
//  Rover
//
//  Created by Brayden Harris on 2/14/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BMHPhotoCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

NS_ASSUME_NONNULL_END
