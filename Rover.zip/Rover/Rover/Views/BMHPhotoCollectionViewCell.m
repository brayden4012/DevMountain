//
//  BMHPhotoCollectionViewCell.m
//  Rover
//
//  Created by Brayden Harris on 2/14/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHPhotoCollectionViewCell.h"

@implementation BMHPhotoCollectionViewCell

- (void)prepareForReuse
{
    [super prepareForReuse];
    [self imageView].image = [UIImage imageNamed:@"MarsPlaceholder"];
}

@end
