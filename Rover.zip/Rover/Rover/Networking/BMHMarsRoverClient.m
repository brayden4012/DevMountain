//
//  BMHMarsRoverClient.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHMarsRoverClient.h"

@implementation BMHMarsRoverClient

// MARK: - Private
+ (NSString *)apiKey
{
    static NSString *apiKey = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSURL *apiKeysURL = [[NSBundle mainBundle] URLForResource:@"APIKey" withExtension:@"plist"];
        if (!apiKeysURL) {
            NSLog(@"Error! APIKeys file not found!");
            return;
        }
        NSDictionary *apiKeys = [[NSDictionary alloc] initWithContentsOfURL:apiKeysURL];
        apiKey = apiKeys[@"APIKey"];
    });

    return apiKey;
}

+ (NSURL *)baseURL
{
    return [NSURL URLWithString:@"https://api.nasa.gov/mars-photos/api/v1"];
}

+ (NSURL *)URLForInfoForRover:(NSString *)roverName
{
    NSURL *roverInfoURL = [self baseURL];
    roverInfoURL = [roverInfoURL URLByAppendingPathComponent:@"manifests"];
    roverInfoURL = [roverInfoURL URLByAppendingPathComponent:roverName];
    
    NSURLComponents *urlComponents = [NSURLComponents componentsWithURL:roverInfoURL resolvingAgainstBaseURL:YES];
    urlComponents.queryItems = @[[NSURLQueryItem queryItemWithName:@"api_key" value:[self apiKey]]];

    return [urlComponents URL];
}

+ (NSURL *)URLForPhotoFromRover:(NSString *)roverName
                            sol:(NSInteger)sol
{
    NSURL *roverPhotoURL = [self baseURL];
    roverPhotoURL = [roverPhotoURL URLByAppendingPathComponent:@"rovers"];
    roverPhotoURL = [roverPhotoURL URLByAppendingPathComponent:roverName];
    roverPhotoURL = [roverPhotoURL URLByAppendingPathComponent:@"photos"];
    
    NSURLComponents *urlComponents = [NSURLComponents componentsWithURL:roverPhotoURL resolvingAgainstBaseURL:YES];
    urlComponents.queryItems = @[[NSURLQueryItem queryItemWithName:@"sol" value:[@(sol) stringValue]], [NSURLQueryItem queryItemWithName:@"api_key" value:[self apiKey]]];
    return [urlComponents URL];
}

// MARK: - Instance Methods
- (void)fetchAllMarsRoversWithCompletion:(void (^)(NSArray * _Nonnull, NSError * _Nullable))completion
{
    NSURL *roversURL = [[[self class] baseURL] URLByAppendingPathComponent:@"rovers"];
    
    NSURLComponents *urlComponents = [NSURLComponents componentsWithURL:roversURL resolvingAgainstBaseURL:YES];
    urlComponents.queryItems = @[[NSURLQueryItem queryItemWithName:@"api_key" value:[[self class] apiKey]]];
    roversURL = [urlComponents URL];
    
    [[[NSURLSession sharedSession] dataTaskWithURL:roversURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"%@", error.localizedDescription);
            completion([NSArray array], [NSError errorWithDomain:@"Error fetching JSON" code:-1 userInfo:nil]);
            return;
        }
        if (!data) {
            NSLog(@"No data found");
            completion([NSArray array], [NSError errorWithDomain:@"Error fetching data" code:-1 userInfo:nil]);
            return;
        }
        
        NSDictionary *jsonDictionaries = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        
        NSArray *roversDictsArray = jsonDictionaries[@"rovers"];

        if (!jsonDictionaries) {
            NSDictionary *userInfo = nil;
            if (error) {
                userInfo = @{NSUnderlyingErrorKey : error };
            }
            NSError *localError = [NSError errorWithDomain:@"Error parsing into JSON" code:-1 userInfo:userInfo];
            return completion([NSArray array], localError);
        }
        
        NSMutableArray *roverNames = [NSMutableArray array];
        for (NSDictionary *dict in roversDictsArray) {
            NSString *name = dict[@"name"];
            if (name) { [roverNames addObject:name]; }
        }

        completion(roverNames, nil);
    }] resume];
}

- (void)fetchMissionManifestForRoverNamed:(NSString *)roverName completion:(void (^)(BMHRover * _Nullable, NSError * _Nullable))completion
{
    NSURL *manifestURL = [[self class] URLForInfoForRover:roverName];

    [[[NSURLSession sharedSession] dataTaskWithURL:manifestURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"%@", error.localizedDescription);
            completion(nil, error);
            return;
        }
        if (!data) {
            NSLog(@"No data found");
            completion(nil, [NSError errorWithDomain:@"Error fetching data" code:-1 userInfo:nil]);
            return;
        }

        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        
        NSDictionary *manifestDict = nil;
        if (!jsonDict || !(manifestDict = jsonDict[@"photo_manifest"])) {
            NSDictionary *userInfo = nil;
            if (error) {
                userInfo = @{NSUnderlyingErrorKey : error };
            }
            NSError *localError = [NSError errorWithDomain:@"Error parsing into JSON" code:-1 userInfo:userInfo];
            return completion(nil, localError);
        }
        
        BMHRover *rover = [[BMHRover alloc] initWithDictionary:manifestDict];
        completion(rover, nil);
    }] resume];
}

- (void)fetchPhotosFromRover:(BMHRover *)rover sol:(NSInteger)sol completion:(void (^)(NSArray * _Nonnull, NSError * _Nullable))completion
{
    if (!rover) {
        NSLog(@"Nil rover");
        completion([NSArray array], [NSError errorWithDomain:@"Nil rover" code:-1 userInfo:nil]);
        return;
    }
    NSURL *photosURL = [[self class] URLForPhotoFromRover:[rover name] sol:sol];
    
    [[[NSURLSession sharedSession] dataTaskWithURL:photosURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"%@", error.localizedDescription);
            completion([NSArray array], error);
            return;
        }
        if (!data) {
            NSLog(@"No data found");
            completion([NSArray array], [NSError errorWithDomain:@"Error fetching data" code:-1 userInfo:nil]);
            return;
        }
        
        NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
        NSArray *photosDictArray = nil;
        
        if (!jsonDictionary || !(photosDictArray = jsonDictionary[@"photos"])) {
            NSDictionary *userInfo = nil;
            if (error) {
                userInfo = @{NSUnderlyingErrorKey : error };
            }
            NSError *localError = [NSError errorWithDomain:@"Error parsing into JSON" code:-1 userInfo:userInfo];
            return completion([NSArray array], localError);
        }
        
        NSMutableArray *photos = [NSMutableArray array];
        for (NSDictionary *dict in photosDictArray) {
            BMHPhoto *photo = [[BMHPhoto alloc] initWithDictionary:dict];
            if (!photo) {
                continue;
            }
            [photos addObject:photo];
        }
        completion(photos, nil);
    }] resume];
}

- (void)fetchImageDataForPhoto:(BMHPhoto *)photo completion:(void (^)(NSData * _Nullable))completion
{
    if (!photo) {
        NSLog(@"Nil photo");
        completion(nil);
        return;
    }
    
    NSURL *imageURL = [NSURL URLWithString:[photo imageURLString]];
    NSURLComponents *urlComponents = [NSURLComponents componentsWithURL:imageURL resolvingAgainstBaseURL:YES];
    urlComponents.scheme = @"https";
    imageURL = [urlComponents URL];
    
    [[[NSURLSession sharedSession] dataTaskWithURL:imageURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"%@", error.localizedDescription);
            completion(nil);
            return;
        }
        if (!data) {
            NSLog(@"No data found");
            completion(nil);
            return;
        }
        
        completion(data);
    }] resume];
}

@end
