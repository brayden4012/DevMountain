//
//  BMHMarsRoverClient.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BMHRover.h"

NS_ASSUME_NONNULL_BEGIN

@interface BMHMarsRoverClient : NSObject

- (void)fetchAllMarsRoversWithCompletion:(void(^)(NSArray *names, NSError * _Nullable error))completion;
- (void)fetchMissionManifestForRoverNamed:(NSString *)roverName
                               completion:(void(^)(BMHRover *rover, NSError * _Nullable error))completion;
- (void)fetchPhotosFromRover:(BMHRover *)rover
                         sol:(NSInteger)sol
                  completion:(void(^)(NSArray *photos, NSError * _Nullable error))completion;
- (void)fetchImageDataForPhoto:(BMHPhoto *)photo
                    completion:(void(^)(NSData * _Nullable imageData))completion;

@end

NS_ASSUME_NONNULL_END
