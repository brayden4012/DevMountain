//
//  BMHPhotosCollectionViewController.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMHMarsRoverClient.h"
#import "BMHPhotoCollectionViewCell.h"
#import "BMHPhotoDetailViewController.h"
#import "BMHPhotoCache.h"

NS_ASSUME_NONNULL_BEGIN

@interface BMHPhotosCollectionViewController : UICollectionViewController

@property (nonatomic, strong)BMHRover *rover;
@property (nonatomic, strong)BMHSolDescription *sol;

@end

NS_ASSUME_NONNULL_END
