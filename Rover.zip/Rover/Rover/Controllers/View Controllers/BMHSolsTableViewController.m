//
//  BMHSolsTableViewController.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHSolsTableViewController.h"

@interface BMHSolsTableViewController ()

@end

@implementation BMHSolsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[_rover solDescriptions] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"solCell" forIndexPath:indexPath];
    
    BMHSolDescription *sol = [[self rover] solDescriptions][indexPath.row];
    [cell textLabel].text = [NSString stringWithFormat:@"Sol %ld", [sol sol]];
    
    [cell detailTextLabel].text = [NSString stringWithFormat:@"%ld Photos", [sol numPhotos]];
    
    return cell;
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"toPhotosSegue"]) {
        NSIndexPath *indexPath = [[self tableView] indexPathForSelectedRow];
        BMHPhotosCollectionViewController *destinationVC = [segue destinationViewController];
        destinationVC.rover = _rover;
        destinationVC.sol = [_rover solDescriptions][indexPath.row];
    }
}

- (void)setRover:(BMHRover *)rover
{
    if (rover != _rover) {
        _rover = rover;
        [[self tableView] reloadData];
    }
}

@end
