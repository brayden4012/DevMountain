//
//  BMHPhotoDetailViewController.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMHMarsRoverClient.h"
#import "BMHPhotosCollectionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BMHPhotoDetailViewController : UIViewController

@property (nonatomic, strong)BMHPhoto *photo;

@end

NS_ASSUME_NONNULL_END
