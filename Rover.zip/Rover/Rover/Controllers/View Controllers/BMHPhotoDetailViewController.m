//
//  BMHPhotoDetailViewController.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHPhotoDetailViewController.h"

@interface BMHPhotoDetailViewController ()

//@property (nonatomic, readonly)BMHMarsRoverClient *client;

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *cameraLabel;
@property (weak, nonatomic) IBOutlet UILabel *solLabel;
@property (weak, nonatomic) IBOutlet UILabel *earthDateLabel;

@end

@implementation BMHPhotoDetailViewController

- (BMHMarsRoverClient *)client
{
    return [[BMHMarsRoverClient alloc] init];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self updateViews];
}

- (void)updateViews
{
    if (_photo) {
        _cameraLabel.text = _photo.cameraName;
        _solLabel.text = [NSString stringWithFormat:@"%@", @(_photo.sol)];
        _earthDateLabel.text = _photo.captureDate;
        
        BMHPhotoCache *cache = [BMHPhotoCache sharedCache];
        NSData *cachedData = [[[BMHPhotoCache class] new] imageDataForIdentifier:[_photo identifier]];
        if (cachedData) {
            UIImage *image = [UIImage imageWithData:cachedData];
            _imageView.image = image;
        }
        else {
            [self.client fetchImageDataForPhoto:_photo completion:^(NSData * _Nullable imageData) {
                [cache cacheImageData:imageData forIdentifier:self.photo.identifier];
                UIImage *image = [UIImage imageWithData:imageData];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.imageView.image = image;
                });
            }];
        }
        [self.inputViewController reloadInputViews];
    }
}




@end
