//
//  BMHRoversTableViewController.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHRoversTableViewController.h"

@interface BMHRoversTableViewController ()

@property (nonatomic, copy)NSArray *rovers;

@end

@implementation BMHRoversTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    dispatch_group_t group = dispatch_group_create();
    NSMutableArray *manifests = [NSMutableArray array];
    
    dispatch_group_enter(group);
    BMHMarsRoverClient *client = [[BMHMarsRoverClient alloc] init];
    [client fetchAllMarsRoversWithCompletion:^(NSArray * _Nonnull names, NSError * _Nullable error) {
        if (error) {
            NSLog(@"Error fetching list of mars rovers: %@", error);
            return;
        }
        
        dispatch_queue_t resultsQueue = dispatch_queue_create("roverFetchResultsQueue", 0);
        
        for (NSString *name in names) {
            dispatch_group_enter(group);
            [client fetchMissionManifestForRoverNamed:name completion:^(BMHRover * _Nonnull rover, NSError * _Nullable error) {
                if (error) {
                    NSLog(@"Error fetching list of rovers: %@", error);
                    dispatch_group_leave(group);
                    return;
                }
                dispatch_async(resultsQueue, ^{
                    [manifests addObject:rover];
                    dispatch_group_leave(group);
                });
            }];
        }
        
        dispatch_group_leave(group);
    }];
    
    dispatch_group_wait(group, DISPATCH_TIME_FOREVER);
    self.rovers = manifests;
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _rovers.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"roverCell" forIndexPath:indexPath];
    
    [cell textLabel].text = [_rovers[indexPath.row] name];
    
    return cell;
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString: @"toSolsSegue"]) {
        NSIndexPath *index = [self.tableView indexPathForSelectedRow];
        BMHSolsTableViewController *destinationVC = [segue destinationViewController];
        destinationVC.rover = _rovers[index.row];
    }
}

- (void)setRovers:(NSArray *)rovers
{
    if (rovers != _rovers) {
        _rovers = [rovers copy];
        [self.tableView reloadData];
    }
}

@end
