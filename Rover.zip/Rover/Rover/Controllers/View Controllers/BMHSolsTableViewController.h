//
//  BMHSolsTableViewController.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMHRoversTableViewController.h"
#import "BMHMarsRoverClient.h"
#import "BMHPhotosCollectionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BMHSolsTableViewController : UITableViewController

@property (nonatomic, strong)BMHRover *rover;

@end

NS_ASSUME_NONNULL_END
