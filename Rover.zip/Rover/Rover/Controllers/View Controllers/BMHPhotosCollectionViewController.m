//
//  BMHPhotosCollectionViewController.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHPhotosCollectionViewController.h"

@interface BMHPhotosCollectionViewController ()

@property (nonatomic, strong, readonly)BMHMarsRoverClient *client;
@property (nonatomic, readwrite)NSArray *photos;

@end

@implementation BMHPhotosCollectionViewController

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    [self fetchPhotoReferences];
}

- (void)fetchPhotoReferences
{
    [[[BMHMarsRoverClient class] new] fetchPhotosFromRover:_rover sol:[_sol sol] completion:^(NSArray * _Nonnull photos, NSError * _Nullable error) {
        if (error) {
            NSLog(@"Error getting photo references for %@ on %@: %@", self.rover, self.sol, error);
            return;
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.photos = photos;
            [[self collectionView] reloadData];
        });
    }];
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"toDetailSegue"]) {
        NSIndexPath *indexPath = [[[self collectionView] indexPathsForSelectedItems] firstObject];
        BMHPhotoDetailViewController *destinationVC = [segue destinationViewController];
        destinationVC.photo = _photos[indexPath.row];
    }
}


#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
        return self.photos.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    BMHPhotoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"photoCell" forIndexPath:indexPath];
    
    BMHPhoto *photo = [self photos][indexPath.row];
    BMHPhotoCache *cache = [BMHPhotoCache sharedCache];
    NSData *cachedData = [cache imageDataForIdentifier:photo.identifier];
    if (cachedData) {
        UIImage *image = [UIImage imageWithData:cachedData];
        [cell imageView].image = image;
    }
    else {
        [cell imageView].image = [UIImage imageNamed:@"MarsPlaceholder"];
    }
    
    [self.client fetchImageDataForPhoto:photo completion:^(NSData * _Nullable imageData) {
        [cache cacheImageData:imageData forIdentifier:photo.identifier];
        UIImage *image = [UIImage imageWithData:imageData];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (![indexPath isEqual:[collectionView indexPathForCell:cell]]) {
                return;
            }
            [cell imageView].image = image;
        });
    }];
    
    return cell;
}

@synthesize client = _client;
- (BMHMarsRoverClient *)client
{
    if (!_client) {
        _client = [[BMHMarsRoverClient alloc] init];
    }
    return _client;
}

@end
