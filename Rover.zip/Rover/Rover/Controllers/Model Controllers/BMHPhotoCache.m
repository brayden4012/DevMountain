//
//  BMHPhotoCache.m
//  Rover
//
//  Created by Brayden Harris on 2/14/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHPhotoCache.h"

@interface BMHPhotoCache ()

@property (nonatomic, strong)NSCache *cache;

@end

@implementation BMHPhotoCache

+ (instancetype)sharedCache
{
    static BMHPhotoCache *sharedCache = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedCache = [self new];
    });
    return sharedCache;
}

- (instancetype)init
{
    if (self = [super init]) {
        _cache = [NSCache new];
        _cache.name = @"photoCache";
    }
    return self;
}

- (void)cacheImageData:(NSData *)data forIdentifier:(NSInteger)identifier
{
    [self.cache setObject:data forKey:@(identifier) cost:[data length]];
}

- (NSData *)imageDataForIdentifier:(NSInteger)identifier
{
    return [self.cache objectForKey:@(identifier)];
}

@end
