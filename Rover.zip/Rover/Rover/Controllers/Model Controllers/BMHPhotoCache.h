//
//  BMHPhotoCache.h
//  Rover
//
//  Created by Brayden Harris on 2/14/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BMHMarsRoverClient.h"

NS_ASSUME_NONNULL_BEGIN

@interface BMHPhotoCache : NSObject

@property (nonatomic, readonly, class)BMHPhotoCache *sharedCache;

- (void)cacheImageData:(NSData *)data forIdentifier:(NSInteger)identifier;

- (NSData *)imageDataForIdentifier:(NSInteger)identifier;

@end

NS_ASSUME_NONNULL_END
