//
//  BMHRover.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BMHSolDescription.h"
#import "BMHPhoto.h"

typedef NS_ENUM(NSInteger, BMHRoverStatus) {
    BMHRoverStatusActive,
    BMHRoverStatusComplete,
};

NS_ASSUME_NONNULL_BEGIN

@interface BMHRover : NSObject

@property (nonatomic, readonly)NSString *name;
@property (nonatomic, readonly)NSString *launchDate;
@property (nonatomic, readonly)NSString *landingDate;
@property (nonatomic, readonly)NSInteger maxSol;
@property (nonatomic, readonly)NSString *maxDate;
@property (nonatomic, readonly)BMHRoverStatus status;
@property (nonatomic, readonly)NSInteger numPhotos;
@property (nonatomic, readonly)NSMutableArray *solDescriptions;

+ (NSString *)nameKey;
+ (NSString *)launchDateKey;
+ (NSString *)landingDateKey;
+ (NSString *)maxSolKey;
+ (NSString *)maxDateKey;
+ (NSString *)statusKey;
+ (NSString *)numPhotosKey;

- (instancetype)initWithName:(NSString *)name
                  launchDate:(NSString *)launchDate
                 landingDate:(NSString *)landingDate
                       maxSol:(NSInteger)maxSol
                     maxDate:(NSString *)maxDate
                      status:(BMHRoverStatus)status
                   numPhotos:(NSInteger)numPhotos
             solDescriptions:(NSArray *)solDescriptions;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
