//
//  BMHPhoto.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BMHPhoto : NSObject

@property (nonatomic, readonly)NSInteger identifier;
@property (nonatomic, readonly)NSInteger sol;
@property (nonatomic, readonly)NSString *cameraName;
@property (nonatomic, readonly)NSString *captureDate;
@property (nonatomic, readonly)NSString *imageURLString;

+ (NSString *)identifierKey;
+ (NSString *)solKey;
+ (NSString *)cameraKey;
+ (NSString *)cameraNameKey;
+ (NSString *)captureDateKey;
+ (NSString *)imageURLKey;

- (BOOL)isEqual:(id)object;

- (instancetype)initWithID:(NSInteger)identifier
                       sol:(NSInteger)sol
                cameraName:(NSString *)cameraName
               captureDate:(NSString *)captureDate
          imageURLAsString:(NSString *)imageURL;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
