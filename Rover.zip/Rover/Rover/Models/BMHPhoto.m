//
//  BMHPhoto.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHPhoto.h"

@implementation BMHPhoto

//MARK: - Dictionary Keys
+ (NSString *)identifierKey
{
    return @"id";
}

+ (NSString *)solKey
{
    return @"sol";
}

+ (NSString *)cameraKey
{
    return @"camera";
}

+ (NSString *)cameraNameKey
{
    return @"name";
}

+ (NSString *)captureDateKey
{
    return @"earth_date";
}

+ (NSString *)imageURLKey
{
    return @"img_src";
}

// MARK: - Initializers
-(instancetype)initWithID:(NSInteger)identifier sol:(NSInteger)sol cameraName:(NSString *)cameraName captureDate:(NSString *)captureDate imageURLAsString:(NSString *)imageURL
{
    if (self = [super init]) {
        _identifier = identifier;
        _sol = sol;
        _cameraName = cameraName;
        _captureDate = captureDate;
        _imageURLString = imageURL;
    }
    return self;
}

-(instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSInteger identifier = [dictionary[[BMHPhoto identifierKey]] integerValue];
    NSInteger sol = [dictionary[[BMHPhoto solKey]] integerValue];
    NSString *cameraName = dictionary[[BMHPhoto cameraKey]][[BMHPhoto cameraNameKey]];
    NSString *captureDate = dictionary[[BMHPhoto captureDateKey]];
    NSString *imageURLString = dictionary[[BMHPhoto imageURLKey]];
    
    return [self initWithID:identifier sol:sol cameraName:cameraName captureDate:captureDate imageURLAsString:imageURLString];
}

// MARK: - Equatable
- (BOOL)isEqual:(id)object
{
    if (!object || ![object isKindOfClass:[BMHPhoto class]]) { return NO; }
    BMHPhoto *photo = object;
    if (photo.identifier != self.identifier) { return NO; }
    if (photo.sol != self.sol) { return NO; }
    if (photo.cameraName != self.cameraName) { return NO; }
    if (photo.captureDate != self.captureDate) { return NO; }
    if (photo.imageURLString != self.imageURLString) { return NO; }
    return YES;
}

@end
