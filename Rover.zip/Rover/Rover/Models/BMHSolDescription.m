//
//  BMHSolDescription.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHSolDescription.h"

@implementation BMHSolDescription

// MARK - Dictionary Keys
+ (NSString *)solKey
{
    return @"sol";
}

+ (NSString *)numPhotosKey
{
    return @"total_photos";
}

+ (NSString *)camerasKey
{
    return @"cameras";
}

// MARK: - Initializers
- (instancetype)initWithSol:(NSInteger)sol numPhotos:(NSInteger)numPhotos cameras:(NSArray *)cameras
{
    if (self = [super init]) {
        _sol = sol;
        _numPhotos = numPhotos;
        _cameras = cameras;
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSInteger sol = [dictionary[[BMHSolDescription solKey]] integerValue];
    NSInteger numPhotos = [dictionary[[BMHSolDescription numPhotosKey]] integerValue];
    NSArray *cameras = [dictionary[[BMHSolDescription camerasKey]] copy];
    
    return [self initWithSol:sol numPhotos:numPhotos cameras:cameras];
}

@end
