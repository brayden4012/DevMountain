//
//  BMHRover.m
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHRover.h"

@implementation BMHRover

// MARK - Dictionary Keys
+ (NSString *)nameKey
{
    return @"name";
}

+ (NSString *)launchDateKey
{
    return @"launch_date";
}

+ (NSString *)landingDateKey
{
    return @"landing_date";
}

+ (NSString *)maxSolKey
{
    return @"max_sol";
}

+ (NSString *)maxDateKey
{
    return @"max_date";
}

+ (NSString *)statusKey
{
    return @"status";
}

+ (NSString *)numPhotosKey
{
    return @"total_photos";
}


// MARK: - Initializers
- (instancetype)initWithName:(NSString *)name launchDate:(NSString *)launchDate landingDate:(NSString *)landingDate maxSol:(NSInteger)maxSol maxDate:(NSString *)maxDate status:(BMHRoverStatus)status numPhotos:(NSInteger)numPhotos solDescriptions:(NSMutableArray *)solDescriptions
{
    if (self = [super init]) {
        _name = name;
        _launchDate = launchDate;
        _landingDate = landingDate;
        _maxSol = maxSol;
        _maxDate = maxDate;
        _status = status;
        _numPhotos = numPhotos;
        _solDescriptions = solDescriptions;
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSString *name = dictionary[[BMHRover nameKey]];
    NSString *launchDate = dictionary[[BMHRover launchDateKey]];
    NSString *landingDate = dictionary[[BMHRover landingDateKey]];
    NSInteger maxSol = [dictionary[[BMHRover maxSolKey]] integerValue];
    NSString *maxDate = dictionary[[BMHRover maxDateKey]];
    BMHRoverStatus status = [dictionary[[BMHRover statusKey]] isEqualToString:@"active"] ? BMHRoverStatusActive : BMHRoverStatusComplete;
    NSInteger numPhotos = [dictionary[[BMHRover numPhotosKey]] integerValue];
    NSMutableArray *solDescriptions = [NSMutableArray array];
    NSArray *solDescriptionsArray = dictionary[@"photos"];
    for (NSDictionary *dict in solDescriptionsArray) {
        BMHSolDescription *solDescription = [[BMHSolDescription alloc] initWithDictionary:dict];
        [solDescriptions addObject:solDescription];
    }
    
    return [self initWithName:name launchDate:launchDate landingDate:landingDate maxSol:maxSol maxDate:maxDate status:status numPhotos:numPhotos solDescriptions:solDescriptions];
}

@end
