//
//  BMHSolDescription.h
//  Rover
//
//  Created by Brayden Harris on 2/13/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BMHSolDescription : NSObject

@property (nonatomic, readonly)NSInteger sol;
@property (nonatomic, readonly)NSInteger numPhotos;
@property (nonatomic, strong, readonly)NSArray *cameras;

+ (NSString *)solKey;
+ (NSString *)numPhotosKey;
+ (NSString *)camerasKey;

- (instancetype)initWithSol:(NSInteger)sol
                  numPhotos:(NSInteger)numPhotos
                    cameras:(NSArray *)cameras;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
