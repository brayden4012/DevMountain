//
//  MovieTableViewCell.swift
//  MovieSearch
//
//  Created by Brayden Harris on 2/8/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class MovieTableViewCell: UITableViewCell {

    // Landing Pad
    var movie: Movie? {
        didSet {
            updateViews()
        }
    }
    
    // MARK: - IBOutlets
    @IBOutlet weak var moviePosterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var summaryLabel: UILabel!
    
    func updateViews() {
        guard let movie = movie else { return }
        
        MovieController.fetchMovieImageFor(movie: movie, completion: { (poster) in
            DispatchQueue.main.async {
                self.moviePosterImageView.image = poster
            }
        })
        titleLabel.text = movie.title
        ratingLabel.text = "Rating: \(String(movie.rating))"
        summaryLabel.text = movie.summary
    }
    
}
