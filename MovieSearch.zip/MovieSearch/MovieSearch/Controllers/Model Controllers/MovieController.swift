//
//  MovieController.swift
//  MovieSearch
//
//  Created by Brayden Harris on 2/8/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class MovieController {
    
    //MARK: - BaseURL's
    static let baseURL = URL(string: "https://api.themoviedb.org/3/search/movie")
    static let baseImageURL = URL(string: "http://image.tmdb.org/t/p/w500")
    
    static func fetchMoviesWith(searchTerm: String, completion: @escaping (([Movie])-> Void)) {
    
        guard let unwrappedURL = baseURL else { print("Error unwrapping the baseURL"); completion([]); return }
    
        var components = URLComponents(url: unwrappedURL, resolvingAgainstBaseURL: true)
        
        let apiKeyQueryItem = URLQueryItem(name: "api_key", value: "43f891cc00b87580310c780699735387")
        let searchTermQueryItem = URLQueryItem(name: "query", value: searchTerm)
        components?.queryItems = [apiKeyQueryItem, searchTermQueryItem]
        
        guard let fullURL = components?.url else { print("Error creating components URL."); completion([]); return }
        
        URLSession.shared.dataTask(with: fullURL) { (data, _, error) in
            if let error = error {
                print("Error fetching Movies from the API: \(error), \(error.localizedDescription)")
                completion([])
                return
            }
            guard let data = data else { print("No data found!"); completion([]); return }
            
            do {
                let decoder = JSONDecoder()
                let movies = try decoder.decode(TopLevelJSON.self, from: data)
                let sortedMovies = movies.results.sorted(by: { $0.rating > $1.rating })
                completion(sortedMovies)
            } catch {
                print("Unable to decode data for the movie \(searchTerm): \(error), \(error.localizedDescription)")
                completion([])
                return
            }
        }.resume()
    }
    
    static func fetchMovieImageFor(movie: Movie, completion: @escaping ((UIImage?) -> Void)) {
        guard let posterEndpoint = movie.poster else { print("No image available"); completion(nil); return }
        guard let fullImageURL = baseImageURL?.appendingPathComponent(posterEndpoint) else { print("Invalid posterEndpoint"); completion(nil); return }
        
        URLSession.shared.dataTask(with: fullImageURL) { (data, _, error) in
            if let error = error {
                print("Error fetching image for \(movie.title): \(error), \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let data = data else { print("No image data found"); completion(nil); return }
            
            let image = UIImage(data: data)
            completion(image)
        }.resume()
    }
}
