//
//  MoviesTableViewController.swift
//  MovieSearch
//
//  Created by Brayden Harris on 2/8/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

import UIKit

class MoviesTableViewController: UITableViewController {

    // MARK: - Source Of truth
    var movies: [Movie] = [] {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    // MARK: - IBOutlets
    @IBOutlet weak var searchBar: UISearchBar!
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return movies.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath) as? MovieTableViewCell

        cell?.movie = movies[indexPath.row]

        return cell ?? UITableViewCell()
    }
}
// MARK: - Search Bar Delegate
extension MoviesTableViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let searchTerm = searchBar.text else { return }
        MovieController.fetchMoviesWith(searchTerm: searchTerm) { (movies) in
            self.movies = movies
        }
    }
}
