//
//  Post.swift
//  Post
//
//  Created by Brayden Harris on 2/4/19.
//  Copyright © 2019 DevMtnStudent. All rights reserved.
//

import Foundation

struct Post: Codable {
    var text: String
    var timestamp: Double
    var username: String
    
    init(username: String, text: String, timestamp: Double = Date().timeIntervalSince1970) {
        self.username = username
        self.text = text
        self.timestamp = timestamp
    }
    
    var date: String? {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: Date(timeIntervalSince1970: timestamp))
    }
    
    var queryTimestamp: TimeInterval {
        return self.timestamp - 0.00001
    }
}
