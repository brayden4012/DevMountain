//
//  RepresentativeController.swift
//  Representative
//
//  Created by Brayden Harris on 2/7/19.
//  Copyright © 2019 DevMtnStudent. All rights reserved.
//

import Foundation

class RepresentativeController {
    static let baseURL = URL(string:"https://whoismyrepresentative.com/getall_reps_bystate.php")
    
    static func searchRepresentatives(forState state: String, completion: @escaping (([Representative]) -> Void)) {
        guard let url = baseURL else { print("Error unwrapping URL"); completion([]); return }
        
        var components = URLComponents(url: url, resolvingAgainstBaseURL: true)
        
        let searchStateQueryItem = URLQueryItem(name: "state", value: state)
        let jsonConversionQueryItem = URLQueryItem(name: "output", value: "json")
        components?.queryItems = [searchStateQueryItem, jsonConversionQueryItem]
        
        guard let componentsURL = components?.url else { completion([]); return }
        
        URLSession.shared.dataTask(with: componentsURL) { (data, _, error) in
            if let error = error {
                print("Error fetching data for \(state): \(error), \(error.localizedDescription)")
                completion([])
                return
            }
            
            guard let data = data else { print("No data found for \(state)"); completion([]); return }
            
            let jsonString = String(data: data, encoding: .ascii)
            guard let jsonData = jsonString?.data(using: .ascii) else { print("Error re-encoding JSON string to data"); completion([]); return}
            
            do {
                let decoder = JSONDecoder()
                let resultsDictionary = try decoder.decode([String: [Representative]].self, from: jsonData)
                guard let reps = resultsDictionary["results"] else { print("No representatives found in dictionary"); completion([]); return }
                let sortedReps = reps.sorted(by: { Int($0.district)! < Int($1.district)! })
                completion(sortedReps)
            } catch {
                print("Error decoding jsonData")
                completion([])
                return
            }
        }.resume()
    }
}
