//
//  Entry.swift
//  JournalCK
//
//  Created by user914505 on 2/25/19.
//  Copyright © 2019 user914505. All rights reserved.
//

import Foundation
import CloudKit

struct Entry {
    
    static let entryKey = "Entry"
    static let titleKey = "title"
    static let textKey = "text"
    static let timestampKey = "timestamp"
    
    var title: String
    var text: String
    var timestamp: Date
    var ckRecordID: CKRecord.ID
    
    init(title: String, text: String, timestamp: Date = Date(), ckRecordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString)) {
        self.title = title
        self.text = text
        self.timestamp = timestamp
        self.ckRecordID = ckRecordID
    }
    
    init?(record: CKRecord) {
        guard let title = record[Entry.titleKey] as? String,
        let text = record[Entry.textKey] as? String,
            let timestamp = record[Entry.timestampKey] as? Date else { return nil }
        
        self.init(title: title, text: text, timestamp: timestamp, ckRecordID: record.recordID)
    }
}

extension Entry: Equatable {
    static func ==(lhs: Entry, rhs: Entry) -> Bool {
        return lhs.title == rhs.title && lhs.text == rhs.text && lhs.timestamp == rhs.timestamp
    }
}

extension CKRecord {
    convenience init(entry: Entry) {
        self.init(recordType: Entry.entryKey, recordID: entry.ckRecordID)
        self.setValue(entry.title, forKey: Entry.titleKey)
        self.setValue(entry.text, forKey: Entry.textKey)
        self.setValue(entry.timestamp, forKey: Entry.timestampKey)
    }
}
