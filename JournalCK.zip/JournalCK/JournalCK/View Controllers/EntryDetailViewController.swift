//
//  EntryDetailViewController.swift
//  JournalCK
//
//  Created by user914505 on 2/25/19.
//  Copyright © 2019 user914505. All rights reserved.
//

import UIKit

class EntryDetailViewController: UIViewController {

    //MARK: - Landing Pad
    var entry: Entry?
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var timestampLabel: UILabel!
    @IBOutlet weak var bodyTextField: UITextView!
    
    //MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        guard let title = titleTextField.text,
            !title.isEmpty,
            let text = bodyTextField.text,
            !text.isEmpty else { return }
        
        if let entry = entry {
            EntryController.shared.update(entry: entry, withTitle: title, andText: text) { (success) in
                if success {
                    DispatchQueue.main.async {
                        self.navigationController?.popViewController(animated: true)
                    }
                } else {
                    print("Failure updating entry")
                }
            }
        } else {
            EntryController.shared.addNewEntryWith(title: title, text: text) { (success) in
                if success {
                    DispatchQueue.main.async {
                        self.navigationController?.popViewController(animated: true)
                    }
                } else {
                    print("Failure updating entry")
                }
            }
        }
    }
    
    //MARK: - Update Views
    func updateViews() {
        if let entry = entry {
            title = ""
            titleTextField.text = entry.title
            bodyTextField.text = entry.text
            timestampLabel.text = EntryController.dateFormatter.string(from: entry.timestamp)
        } else {
            timestampLabel.text = EntryController.dateFormatter.string(from: Date())
        }
    }
}
extension EntryDetailViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return true
    }
}
