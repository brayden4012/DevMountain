//
//  EntryController.swift
//  JournalCK
//
//  Created by user914505 on 2/25/19.
//  Copyright © 2019 user914505. All rights reserved.
//

import Foundation
import CloudKit

class EntryController {
    
    //MARK: - Shared Instance
    static let shared = EntryController()
    
    //MARK: - Date Formatter
    static var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        formatter.locale = Locale.current
        
        return formatter
    }
    
    //MARK: - Source of Truth
    var entries: [Entry] = []
    
    //MARK: - Private DB
    let privateDB = CKContainer.default().privateCloudDatabase
    
    func save(entry: Entry, completion: @escaping (Bool) -> Void) {
        let entryRecord = CKRecord(entry: entry)
        privateDB.save(entryRecord) { (record, error) in
            if let error = error {
                print("Error saving entry to Cloud Kit: \(error), \(error.localizedDescription)")
                completion(false)
                return
            }
            
            guard let record = record,
                let entry = Entry(record: record) else { completion(false); return }
            
            self.entries.append(entry)
            completion(true)
        }
    }
    
    // MARK: - CRUD Functions
    func addNewEntryWith(title: String, text: String, completion: @escaping (Bool) -> Void) {
        let newEntry = Entry(title: title, text: text)
        save(entry: newEntry) { (success) in
            if success {
                completion(true)
            } else {
                completion(false)
            }
        }
    }
    
    func update(entry: Entry, withTitle title: String, andText text: String, completion: @escaping (Bool) -> Void) {
        
        //Update Locally
        guard let entryIndex = entries.index(of: entry) else { completion(false); return }
        var entry = EntryController.shared.entries[entryIndex]
        
        entry.title = title
        entry.text = text
        entry.timestamp = Date()
        
        //Update CloudKit
        privateDB.fetch(withRecordID: entry.ckRecordID) { (record, error) in
            if let error = error {
                print("Error fetching entry from CloudKit: \(error), \(error.localizedDescription)")
                completion(false)
                return
            }
            guard let record = record else { completion(false); return }
            
            record[Entry.titleKey] = title
            record[Entry.textKey] = text
            record[Entry.timestampKey] = Date()
            
            let operation = CKModifyRecordsOperation(recordsToSave: [record], recordIDsToDelete: nil)
            operation.savePolicy = .changedKeys
            operation.queuePriority = .high
            operation.qualityOfService = .userInitiated
            operation.modifyRecordsCompletionBlock = { (records, recordIDs, error) in
                completion(true)
            }
            self.privateDB.add(operation)
        }
    }
    
    func delete(entry: Entry, completion: @escaping (Bool) -> Void) {
        //Delete Locally
        guard let entryIndex = entries.index(of: entry) else { completion(false); return }
        EntryController.shared.entries.remove(at: entryIndex)
        
        //Delete from CloudKit
        privateDB.delete(withRecordID: entry.ckRecordID) { (_, error) in
            if let error = error {
                print("Error deleting entry from CloudKit: \(error), \(error.localizedDescription)")
                completion(false)
                return
            }
            completion(true)
        }
    }
    
    func fetchEntries(completion: @escaping (Bool) -> Void) {
        let predicate = NSPredicate(value: true)
        let query = CKQuery(recordType: Entry.entryKey, predicate: predicate)
        
        privateDB.perform(query, inZoneWith: nil) { (records, error) in
            guard let records = records else { completion(false); return }
            
            self.entries = records.compactMap({ (record) -> Entry? in
                Entry(record: record)
            })
            completion(true)
        }
    }
}
