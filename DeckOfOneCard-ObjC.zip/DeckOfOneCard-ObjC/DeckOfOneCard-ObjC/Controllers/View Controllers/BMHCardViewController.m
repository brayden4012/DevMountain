//
//  BMHCardViewController.m
//  DeckOfOneCard-ObjC
//
//  Created by Brayden Harris on 2/12/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHCardViewController.h"

@interface BMHCardViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *cardImageView;
@property (weak, nonatomic) IBOutlet UILabel *cardLabel;

@end

@implementation BMHCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self updateViews];
    // Do any additional setup after loading the view.
}

- (IBAction)drawButtonTapped:(id)sender {
    [self updateViews];
}

- (void)updateViews
{
    [[BMHCardController sharedController] drawNewCard:1 completion:^(NSArray<BMHCard *> * _Nonnull cards, NSError * _Nonnull error) {
        BMHCard *card = [cards objectAtIndex:0];
        NSLog(@"%@ of %@", card.number, card.suit);
        
        [[BMHCardController sharedController] fetchCardImage:card completion:^(UIImage * _Nonnull image, NSError * _Nonnull error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.cardImageView.image = image;
            });
        }];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.cardLabel.text = [[NSString alloc] initWithFormat:@"%@ of %@", card.number, card.suit];
            if ([card.suit isEqualToString:@"SPADES"] || [card.suit isEqualToString:@"CLUBS"]) {
                self.cardLabel.textColor = [UIColor blackColor];
            }
            else {
                self.cardLabel.textColor = [UIColor redColor];
            }
            
        });
    }];
    
}

@end
