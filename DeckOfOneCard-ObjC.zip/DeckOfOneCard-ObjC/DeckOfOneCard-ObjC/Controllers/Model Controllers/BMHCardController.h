//
//  BMHCardController.h
//  DeckOfOneCard-ObjC
//
//  Created by Brayden Harris on 2/12/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMHCard.h"

NS_ASSUME_NONNULL_BEGIN

@interface BMHCardController : NSObject

+ (instancetype)sharedController;

- (void)drawNewCard:(NSInteger)numberOfCards completion:(void(^) (NSArray<BMHCard *> *cards, NSError *error))completion;

- (void)fetchCardImage:(BMHCard *)card completion:(void(^) (UIImage *image, NSError *error))completion;

@end

NS_ASSUME_NONNULL_END
