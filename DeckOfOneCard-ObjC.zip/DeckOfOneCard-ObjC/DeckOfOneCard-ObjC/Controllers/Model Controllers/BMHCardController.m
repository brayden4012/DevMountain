//
//  BMHCardController.m
//  DeckOfOneCard-ObjC
//
//  Created by Brayden Harris on 2/12/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHCardController.h"

@implementation BMHCardController

+(instancetype)sharedController
{
    static BMHCardController *sharedController = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedController = [[BMHCardController alloc] init];
    });
    return sharedController;
}

+(NSURL *)baseURL
{
    return [NSURL URLWithString:@"https://deckofcardsapi.com/api/deck/new/draw/"];
}

-(void)drawNewCard:(NSInteger)numberOfCards completion:(void (^)(NSArray<BMHCard *> * , NSError *))completion
{
    NSString *cardCount = [@(numberOfCards) stringValue];
    NSURLComponents *components = [NSURLComponents componentsWithURL:[BMHCardController baseURL] resolvingAgainstBaseURL:true];
    NSURLQueryItem *queryItem = [NSURLQueryItem queryItemWithName:@"count" value:cardCount];
    components.queryItems = @[queryItem];
    NSURL *searchURL = components.URL;
    
    [[[NSURLSession sharedSession] dataTaskWithURL:searchURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"%@", error.localizedDescription);
            completion(nil, [NSError errorWithDomain:@"Error fetching JSON" code:-1 userInfo:nil]);
            return;
        }
        if (!data) {
            NSLog(@"No data found");
            completion(nil, [NSError errorWithDomain:@"Error fetching data" code:-1 userInfo:nil]);
        }
        
        NSDictionary *jsonDictionaries = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
        
        NSArray *cardsArray = jsonDictionaries[@"cards"];
        NSMutableArray *cardsPlaceholder = [NSMutableArray array];
        
        for (NSDictionary *dict in cardsArray) {
            BMHCard *card = [[BMHCard alloc]initWithDictionary:dict];
            [cardsPlaceholder addObject:card];
        }
        completion(cardsPlaceholder, nil);
    }] resume];
}

-(void)fetchCardImage:(BMHCard *)card completion:(void (^)(UIImage *, NSError *))completion
{
    NSURL *url = [NSURL URLWithString:card.imageURLString];
    
    [[[NSURLSession sharedSession] dataTaskWithURL:(url) completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"%@", error.localizedDescription);
            completion(nil, [NSError errorWithDomain:@"Error fetching JSON" code:-1 userInfo:nil]);
            return;
        }
        if (!data) {
            NSLog(@"No data found");
            completion(nil, [NSError errorWithDomain:@"Error fetching data" code:-1 userInfo:nil]);
        }
        
        UIImage *cardImage = [UIImage imageWithData:data];
        completion(cardImage, nil);
    }] resume];
}

@end
