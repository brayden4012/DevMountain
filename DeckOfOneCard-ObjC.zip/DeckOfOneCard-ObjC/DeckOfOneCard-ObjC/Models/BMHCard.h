//
//  BMHCard.h
//  DeckOfOneCard-ObjC
//
//  Created by Brayden Harris on 2/12/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BMHCard : NSObject

@property (nonatomic, copy) NSString *suit;
@property (nonatomic, copy) NSString *number;
@property (nonatomic, copy) NSString *imageURLString;

+ (NSString *)suitKey;
+ (NSString *)numberKey;
+ (NSString *)imageKey;

- (instancetype)initWithSuit:(NSString *)suit
                      number:(NSString *)number
              imageURLString:(NSString *)imageURLString;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
