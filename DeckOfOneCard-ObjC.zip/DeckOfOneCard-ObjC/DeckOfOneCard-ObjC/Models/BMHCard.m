//
//  BMHCard.m
//  DeckOfOneCard-ObjC
//
//  Created by Brayden Harris on 2/12/19.
//  Copyright © 2019 Brayden Harris. All rights reserved.
//

#import "BMHCard.h"

@implementation BMHCard

+ (NSString *)suitKey
{
    return @"suit";
}

+(NSString *)numberKey
{
    return @"value";
}

+ (NSString *)imageKey
{
    return @"image";
}

-(instancetype)initWithSuit:(NSString *)suit number:(NSString *)number imageURLString:(NSString *)imageURLString
{
    if (self = [super init]) {
        _suit = suit;
        _number = number;
        _imageURLString = imageURLString;
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSString *suit = dictionary[[BMHCard suitKey]];
    NSString *number = dictionary[[BMHCard numberKey]];
    NSString *imageURLString = dictionary[[BMHCard imageKey]];
    
    return [self initWithSuit:suit number:number imageURLString:imageURLString];
}

@end
